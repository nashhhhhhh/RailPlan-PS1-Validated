"""Scenario B CP-SAT model: fixed dates, flexible supply and optional ECLO."""
from collections import defaultdict
from datetime import date
from time import monotonic
from ortools.sat.python import cp_model
from .contracts import Placement


def solve(dataset, data, options):
    built_at=monotonic(); model=cp_model.CpModel()
    activities,projects=data['activities'],data['projects']
    horizon,nights=data['horizon'],options.physical_nights_per_week
    weeks=range(1,horizon+1); night_ids=range(1,nights+1)
    guards={}
    def guard(code):
        if code not in guards:
            guards[code]=model.NewBoolVar('rule:'+code);model.AddAssumption(guards[code])
        return guards[code]
    def enforce(expression,code):
        return model.Add(expression).OnlyEnforceIf(guard(code))

    active,W,N,L,E,z,x,present,physical_week,local,completion,start_week={},{},{},{},{},{},{},{},{},{},{},{}
    by_project=defaultdict(list);by_location=defaultdict(list)
    required_scaled={};delivered_scaled={};over_delivery={}
    for aid,a in activities.items():
        project=projects[a['contract_number'],a['activity_type']]
        cap=project['number_of_maximum_access_per_week']
        by_project[a['contract_number'],a['activity_type']].append(aid)
        for loc in sorted(data['footprints'][aid]['occupied']):by_location[loc].append(aid)
        for w in weeks:
            present[aid,w]=model.NewBoolVar(f'present:{aid}:{w}')
            physical_week[aid,w]=model.NewIntVar(0,nights,f'physical_week:{aid}:{w}')
            local[aid,w]=model.NewIntVar(0,cap,f'local:{aid}:{w}')
            for n in night_ids:x[aid,w,n]=model.NewBoolVar(f'x:{aid}:{w}:{n}')
            model.Add(sum(x[aid,w,n] for n in night_ids)==present[aid,w])
            model.Add(physical_week[aid,w]==sum(n*x[aid,w,n] for n in night_ids))
            if w<a['planned_start_week']:enforce(present[aid,w]==0,'planned_start')
        maximum=a['total_accesses']
        for k in range(1,maximum+1):
            key=aid,k
            active[key]=model.NewBoolVar(f'active:{aid}:{k}')
            W[key]=model.NewIntVar(0,horizon,f'week:{aid}:{k}')
            N[key]=model.NewIntVar(0,nights,f'physical:{aid}:{k}')
            L[key]=model.NewIntVar(0,cap,f'access_night:{aid}:{k}')
            E[key]=model.NewBoolVar(f'eclo:{aid}:{k}')
            choices=[]
            for w in weeks:
                for n in night_ids:
                    value=model.NewBoolVar(f'z:{aid}:{k}:{w}:{n}')
                    z[aid,k,w,n]=value;choices.append(value)
            model.Add(sum(choices)==active[key])
            model.Add(W[key]==sum(w*z[aid,k,w,n] for w in weeks for n in night_ids))
            model.Add(N[key]==sum(n*z[aid,k,w,n] for w in weeks for n in night_ids))
            model.AddElement(W[key],[0]+[local[aid,w] for w in weeks],L[key])
            model.Add(E[key]<=active[key])
            if k==1:enforce(active[key]==1,'workload')
            else:
                model.Add(active[key]<=active[aid,k-1])
                model.Add(W[key]>W[aid,k-1]).OnlyEnforceIf(active[key],guard('access_sequence'))
        for w in weeks:
            for n in night_ids:model.Add(x[aid,w,n]==sum(z[aid,k,w,n] for k in range(1,maximum+1)))
            enforce(sum(z[aid,k,w,n] for k in range(1,maximum+1) for n in night_ids)<=1,'weekly_activity_access')
        required_scaled[aid]=2*a['total_accesses']
        delivered_scaled[aid]=sum(2*active[aid,k]+E[aid,k] for k in range(1,maximum+1))
        enforce(delivered_scaled[aid]>=required_scaled[aid],'workload')
        over_delivery[aid]=model.NewIntVar(0,2*maximum,f'over_delivery:{aid}')
        model.Add(over_delivery[aid]==delivered_scaled[aid]-required_scaled[aid])
        completion[aid]=model.NewIntVar(1,horizon,f'completion:{aid}')
        model.AddMaxEquality(completion[aid],[W[aid,k] for k in range(1,maximum+1)])
        candidates=[]
        for k in range(1,maximum+1):
            candidate=model.NewIntVar(1,horizon+1,f'start_candidate:{aid}:{k}')
            model.Add(candidate==W[aid,k]).OnlyEnforceIf(active[aid,k])
            model.Add(candidate==horizon+1).OnlyEnforceIf(active[aid,k].Not())
            candidates.append(candidate)
        start_week[aid]=model.NewIntVar(1,horizon,f'start:{aid}')
        model.AddMinEquality(start_week[aid],candidates)

    for aid,a in activities.items():
        if a['predecessor_activity_id']:
            enforce(start_week[aid]>completion[a['predecessor_activity_id']],'dependency')

    # Contract-local access-night labels remain independent from physical nights.
    for key,ids in sorted(by_project.items()):
        project=projects[key];cap=project['number_of_maximum_access_per_week']
        for w in weeks:
            used=[];labels=[]
            for n in night_ids:
                u=model.NewBoolVar(f'used:{key}:{w}:{n}')
                model.AddMaxEquality(u,[x[aid,w,n] for aid in ids]);used.append(u)
                label=model.NewIntVarFromDomain(cp_model.Domain.FromValues([-n]+list(range(1,cap+1))),f'label:{key}:{w}:{n}')
                model.Add(label==-n).OnlyEnforceIf(u.Not());model.Add(label>=1).OnlyEnforceIf(u);labels.append(label)
                enforce(sum(x[aid,w,n] for aid in ids)<=project['number_of_workfronts'],'workfront')
            model.AddAllDifferent(labels);enforce(sum(used)<=cap,'weekly_allocation')
            for aid in ids:model.AddElement(physical_week[aid,w],[0]+labels,local[aid,w])

    excess={};slots={}
    for loc,ids in sorted(by_location.items()):
        pm=[aid for aid in ids if projects[activities[aid]['contract_number'],activities[aid]['activity_type']]['access_type']=='PM']
        pc=[aid for aid in ids if projects[activities[aid]['contract_number'],activities[aid]['activity_type']]['access_type']=='PC']
        for w in weeks:
            loc_slots=[]
            for n in night_ids:
                slot=model.NewBoolVar(f'possession:{loc}:{w}:{n}');slots[loc,w,n]=slot
                model.AddMaxEquality(slot,[x[aid,w,n] for aid in ids]);loc_slots.append(slot)
                enforce(sum(x[aid,w,n] for aid in pc)<=1,'possession_mix')
                enforce(sum(x[aid,w,n] for aid in pm)<=1,'possession_mix')
                enforce(sum(x[aid,w,n] for aid in ids)<=4-3*sum(x[aid,w,n] for aid in pm),'possession_mix')
            used=sum(loc_slots);cap=data['supply'][loc]
            excess[loc,w]=model.NewIntVar(0,nights,f'excess:{loc}:{w}')
            model.AddMaxEquality(excess[loc,w],[0,used-cap])

    for pair in data['pairs']:
        aid,bid=pair['activity_ids']
        for w in weeks:
            for n in night_ids:enforce(x[aid,w,n]+x[bid,w,n]<=1,'physical_closure')

    for placement in sorted(options.locked_placements,key=lambda r:(r.activity_id,r.access_seq)):
        key=placement.activity_id,placement.access_seq;code=f'lock:{key[0]}:{key[1]}'
        enforce(active[key]==1,code);enforce(W[key]==placement.week,code);enforce(N[key]==placement.physical_night,code)
        if placement.access_night is not None:enforce(L[key]==placement.access_night,code)
        if placement.eclo is not None:enforce(E[key]==placement.eclo,code)

    origin=date.fromisoformat(dataset['parameters']['horizon_start']);contract_completion={}
    for contract in sorted({a['contract_number'] for a in activities.values()}):
        ids=[aid for aid,a in activities.items() if a['contract_number']==contract]
        end=model.NewIntVar(1,horizon,f'contract_end:{contract}')
        model.AddMaxEquality(end,[completion[aid] for aid in ids]);contract_completion[contract]=end
        project=next(p for p in projects.values() if p['contract_number']==contract)
        last_week=(date.fromisoformat(project['planned_completion_date'])-origin).days
        allowed=(last_week+1)//7
        enforce(end<=allowed,'planned_date')

    movement=[]
    for placement in sorted(options.baseline_placements,key=lambda r:(r.activity_id,r.access_seq)):
        key=placement.activity_id,placement.access_seq;changes=[]
        for name,var,value in [('week',W[key],placement.week),('physical',N[key],placement.physical_night),('local',L[key],placement.access_night),('eclo',E[key],placement.eclo)]:
            if value is None:continue
            changed=model.NewBoolVar(f'changed:{key}:{name}')
            model.Add(var!=value).OnlyEnforceIf(changed);model.Add(var==value).OnlyEnforceIf(changed.Not());changes.append(changed)
        moved=model.NewBoolVar(f'moved:{key}')
        if changes:model.AddMaxEquality(moved,changes)
        else:model.Add(moved==0)
        movement.append(moved)

    total_excess=sum(excess.values());total_eclo=sum(E.values());official=7*total_excess+5*total_eclo
    objectives=[('official_scenario_b_objective',official),('excess_access_nights_total',total_excess),
        ('eclo_nights_total',total_eclo),('workload_over_delivery_scaled',sum(over_delivery.values())),
        ('completion_weeks',sum(completion.values())+sum(contract_completion.values())),('baseline_movements',sum(movement)),
        ('stable_placement_rank',sum((i+1)*(W[key]*(nights+1)*2003+N[key]*2003+L[key]*2+E[key]) for i,key in enumerate(sorted(W))))]
    build_seconds=monotonic()-built_at;error=model.Validate()
    if error:return {'status':'MODEL_INVALID','placements':None,'diagnostics':[{'code':'model_invalid','message':error}], 'stages':[], 'solve_time_seconds':0,'primary_optimal':False,'lexicographic_complete':False,'build_seconds':build_seconds,'baseline_movement':0}
    solved_at=monotonic();deterministic_used=0.0;candidate=None;status='UNKNOWN';primary_optimal=False;stages=[];diagnostics=[];movement_value=0
    for name,objective in objectives:
        wall=options.time_limit_seconds-(monotonic()-solved_at);det=options.deterministic_time_limit-deterministic_used
        if wall<=0 or det<=0:break
        model.Minimize(objective);solver=cp_model.CpSolver();solver.parameters.num_search_workers=1
        solver.parameters.random_seed=options.random_seed;solver.parameters.max_time_in_seconds=wall;solver.parameters.max_deterministic_time=det
        result=solver.Solve(model);stage_status=solver.StatusName(result);deterministic_used+=solver.ResponseProto().deterministic_time
        stage={'name':name,'status':stage_status,'wall_seconds':solver.WallTime(),'deterministic_seconds':solver.ResponseProto().deterministic_time,
            'best_bound':solver.BestObjectiveBound(),'optimality_proven':result==cp_model.OPTIMAL}
        stages.append(stage)
        if result not in (cp_model.OPTIMAL,cp_model.FEASIBLE):
            if candidate is None:
                status=stage_status
                if result==cp_model.INFEASIBLE:
                    core=set(solver.SufficientAssumptionsForInfeasibility())
                    diagnostics.append({'code':'infeasible_constraint_core','constraint_families':[code for code,g in sorted(guards.items()) if g.Index() in core],
                        'message':'Sufficient (not necessarily minimal) assumption core; structural channeling constraints also apply.'})
            break
        value=int(solver.Value(objective));stage['value']=value
        stage['gap']=0 if result==cp_model.OPTIMAL else max(0,(value-solver.BestObjectiveBound())/max(abs(value),1))
        candidate=[]
        for aid,a in activities.items():
            seq=0
            for k in range(1,a['total_accesses']+1):
                if solver.Value(active[aid,k]):
                    seq+=1;candidate.append(Placement(activity_id=aid,access_seq=seq,week=solver.Value(W[aid,k]),physical_night=solver.Value(N[aid,k]),access_night=solver.Value(L[aid,k]),eclo=solver.Value(E[aid,k])))
        candidate.sort(key=lambda r:(r.activity_id,r.access_seq));movement_value=sum(solver.Value(v) for v in movement)
        status='FEASIBLE'
        if name==objectives[0][0]:primary_optimal=result==cp_model.OPTIMAL
        if result!=cp_model.OPTIMAL:break
        model.Add(objective==value);model.ClearHints()
        for variable in list(W.values())+list(N.values())+list(L.values())+list(E.values()):model.AddHint(variable,solver.Value(variable))
    complete=len(stages)==len(objectives) and all(s['status']=='OPTIMAL' for s in stages)
    if complete:status='OPTIMAL'
    if candidate is None and status=='UNKNOWN':diagnostics.append({'code':'search_limit','message':'No incumbent within the configured solve budgets. This does not prove infeasibility.'})
    if candidate is None:diagnostics.append({'code':'physical_pair_constraints','incompatible_pairs':data['pairs']})
    return {'status':status,'placements':candidate,'diagnostics':diagnostics,'stages':stages,'primary_optimal':primary_optimal,
        'lexicographic_complete':complete,'solve_time_seconds':monotonic()-solved_at,'build_seconds':build_seconds,'baseline_movement':movement_value}
